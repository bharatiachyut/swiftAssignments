import Foundation

class User
{
    func addUserDetails()
    {
        
        print("Enter Name: ")
        var name = readLine()
        print("Enter Age: ")
        if let age = readLine()
        {}
        
        
    }
    func displayUserDetails()
    {}
    func deleteUserDetails()
    {}
    func saveUserDetails()
    {}
}
