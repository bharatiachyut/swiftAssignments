//: [Previous](@previous)

import Foundation
class man{
    var name = ""
    var age = 1
    init(){}
    init(_ name: String, _ age: Int){
        self.name = name
        self.age = age
    }
}

class boy: man{
    
    
}

let a = man("Raju", 48)
let b = boy()
print(a.name)
print(a.age)
